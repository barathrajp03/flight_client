package com.passenger.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.passenger.entity.Passenger;
import com.passenger.exception.PassengerNotFoundException;

@Service
public interface PassengerService {

	public List<Passenger> addPassenger(List<Passenger> passengerList, int bookingId);
	public List<Passenger> getPassengersListByBookingId(int bookingId);
	public Passenger deletePassenger(int passengerId);
	public Passenger getPassengerByPassengerId(int passengerId) throws PassengerNotFoundException;
	
	
	
	
}
