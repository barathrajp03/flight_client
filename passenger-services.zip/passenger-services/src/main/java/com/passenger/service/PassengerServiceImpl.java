package com.passenger.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.passenger.entity.Passenger;
import com.passenger.exception.PassengerNotFoundException;
import com.passenger.repository.PassengerRepository;

@Service
public class PassengerServiceImpl implements PassengerService {
	
	@Autowired
	PassengerRepository passengerRepository;

	@Override
	public List<Passenger> addPassenger(List<Passenger> passengerList, int bookingId) {
		// TODO Auto-generated method stub
		for(Passenger passenger: passengerList ) {
			passenger.setBookingId(bookingId);
			passengerRepository.save(passenger);
		}		
		return passengerList;	
	}

	@Override
	public List<Passenger> getPassengersListByBookingId(int bookingId) {
		// TODO Auto-generated method stub
		return passengerRepository.findByBookingId(bookingId);
	}

	@Override
	public Passenger deletePassenger(int passengerId) {
		// TODO Auto-generated method stub
		Optional<Passenger> ps = passengerRepository.findById(passengerId);
		Passenger passengerObj = ps.get();
		int bookingId = passengerObj.getBookingId();
		passengerRepository.deleteById(passengerId);
		System.out.println("efghjkl;.'/");
		System.out.println(passengerObj);
		return passengerObj;
	}

	@Override
	public Passenger getPassengerByPassengerId(int passengerId) throws PassengerNotFoundException {
		// TODO Auto-generated method stub
		Optional<Passenger> passengerObj =  passengerRepository.findById(passengerId);
		
		if(passengerObj.isEmpty()) {
			throw new PassengerNotFoundException("Passenger with given passenger is not found");
		}
		
		
		return passengerObj.get();
		
		
	
	}

}
