package com.passenger.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Passenger {


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int passengerId;
	private String firstName;
	private String lastName;
	private String age;
	private String gender;
	private String mailId;
	private String phoneNumber;
	private String passportNumber;
	private String seatName;
	private int bookingId;
}
