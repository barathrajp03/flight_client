package com.passenger.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.passenger.entity.Passenger;
import com.passenger.exception.PassengerNotFoundException;
import com.passenger.service.PassengerService;

@RestController
@RequestMapping("/passenger")
public class PassengerController {

	@Autowired
	PassengerService passengerService;
	
	@PostMapping("/add/{bookingId}")
	public List<Passenger> addPassengersByBookingId(@RequestBody List<Passenger> passengersList,@PathVariable int bookingId ){
		return passengerService.addPassenger(passengersList,bookingId);
	}
	
	@GetMapping("/get/{bookingId}")
	public List<Passenger> getPassengersListByBookingId(@PathVariable int bookingId){
		return passengerService.getPassengersListByBookingId( bookingId);
	}
	
	@GetMapping("/getByPassengerId/{passengerId}")
	public Passenger getPassengerByPassengerId(@PathVariable int passengerId) throws PassengerNotFoundException{
		return passengerService.getPassengerByPassengerId(passengerId);
	}
	
	@DeleteMapping("/delete/{passengerId}")
	public Passenger deletePassenger(@PathVariable int passengerId) {
		
		return passengerService.deletePassenger( passengerId);
	}
	
	
}
