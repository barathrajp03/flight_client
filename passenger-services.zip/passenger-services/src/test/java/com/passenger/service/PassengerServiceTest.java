package com.passenger.service;

import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;



import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.passenger.entity.Passenger;
import com.passenger.repository.PassengerRepository;

public class PassengerServiceTest {

	
	
	    @Mock
	    private PassengerRepository passengerRepository;

	    @InjectMocks
	    private PassengerServiceImpl passengerService;

	    @BeforeEach
	    public void setUp() {
	        MockitoAnnotations.openMocks(this);
	    }

	    @Test
	    public void testAddPassenger_Success() {
	        // Prepare the input data
	        int bookingId = 1;
	        Passenger passenger1 = new Passenger();
	        Passenger passenger2 = new Passenger();
	        List<Passenger> passengers = Arrays.asList(passenger1, passenger2);

	        // Mock the repository save method
	        when(passengerRepository.save(any(Passenger.class))).thenAnswer(invocation -> invocation.getArgument(0));

	        // Call the method to be tested
	        List<Passenger> result = passengerService.addPassenger(passengers, bookingId);

	        // Assert the result
	        assertNotNull(result);
	        assertEquals(2, result.size());
	        assertEquals(bookingId, result.get(0).getBookingId());
	        assertEquals(bookingId, result.get(1).getBookingId());

	        // Verify the save method is called
	        verify(passengerRepository, times(2)).save(any(Passenger.class));
	    }

	    @Test
	    public void testGetPassengersListByBookingId_Success() {
	        // Prepare the input and mock data
	        int bookingId = 1;
	        Passenger passenger1 = new Passenger();
	        Passenger passenger2 = new Passenger();
	        List<Passenger> passengers = Arrays.asList(passenger1, passenger2);

	        when(passengerRepository.findByBookingId(bookingId)).thenReturn(passengers);

	        // Call the method to be tested
	        List<Passenger> result = passengerService.getPassengersListByBookingId(bookingId);

	        // Assert the result
	        assertNotNull(result);
	        assertEquals(2, result.size());

	        // Verify the findByBookingId method is called
	        verify(passengerRepository, times(1)).findByBookingId(bookingId);
	    }

	    @Test
	    public void testDeletePassenger_Success() {
	        // Prepare the input and mock data
	        int passengerId = 1;
	        Passenger passenger = new Passenger();
	        passenger.setBookingId(2);

	        when(passengerRepository.findById(passengerId)).thenReturn(Optional.of(passenger));

	        // Call the method to be tested
	        Passenger result = passengerService.deletePassenger(passengerId);

	        // Assert the result
	        assertNotNull(result);
	        assertEquals(passenger.getBookingId(), result.getBookingId());

	        // Verify the methods are called
	        verify(passengerRepository, times(1)).findById(passengerId);
	        verify(passengerRepository, times(1)).deleteById(passengerId);
	    }

	    @Test
	    public void testDeletePassenger_Failure() {
	        // Prepare the input
	        int passengerId = 1;

	        when(passengerRepository.findById(passengerId)).thenReturn(Optional.empty());

	        // Call the method to be tested and assert exception
	        Exception exception = assertThrows(RuntimeException.class, () -> {
	            passengerService.deletePassenger(passengerId);
	        });

	        // Verify the findById method is called
	        verify(passengerRepository, times(1)).findById(passengerId);
	        verify(passengerRepository, never()).deleteById(passengerId);
	    }

	    @Test
	    public void testGetPassengerByPassengerId_Success() throws Exception {
	        // Prepare the input and mock data
	        int passengerId = 1;
	        Passenger passenger = new Passenger();

	        when(passengerRepository.findById(passengerId)).thenReturn(Optional.of(passenger));

	        // Call the method to be tested
	        Passenger result = passengerService.getPassengerByPassengerId(passengerId);

	        // Assert the result
	        assertNotNull(result);
	        assertEquals(passenger, result);

	        // Verify the findById method is called
	        verify(passengerRepository, times(1)).findById(passengerId);
	    }

	    @Test
	    public void testGetPassengerByPassengerId_Failure() {
	        // Prepare the input
	        int passengerId = 1;

	        when(passengerRepository.findById(passengerId)).thenReturn(Optional.empty());

	        // Call the method to be tested and assert exception
	        Exception exception = assertThrows(RuntimeException.class, () -> {
	            passengerService.getPassengerByPassengerId(passengerId);
	        });

	        // Verify the findById method is called
	        verify(passengerRepository, times(1)).findById(passengerId);
	    }
	    
	    @Test
	    public void testAddPassenger_Failure() {
	        // Simulate an exception when saving the passenger
	        when(passengerRepository.save(any(Passenger.class))).thenThrow(new RuntimeException("Failed to save passenger"));

	        Passenger passenger = new Passenger();
	        passenger.setFirstName("Jane Doe");

	        // Attempt to add the passenger
	        Exception exception = assertThrows(RuntimeException.class, () -> {
	            passengerService.addPassenger(Arrays.asList(passenger), 100);
	        });

	        // Assert that the exception message contains the expected error message
	        String expectedMessage = "Failed to save passenger";
	        String actualMessage = exception.getMessage();

	        // Additional assertions can be added if necessary
	        assertTrue(actualMessage.contains(expectedMessage));
	    }

	    @Test
	    public void testGetPassengersListByBookingId_Failure() {
	        // Simulate no passengers found for booking ID 100
	        when(passengerRepository.findByBookingId(100)).thenReturn(Collections.emptyList());

	        // Attempt to retrieve passengers for booking ID 100
	        List<Passenger> passengers = passengerService.getPassengersListByBookingId(100);

	        // Assert that the returned list is empty
	        assertEquals(0, passengers.size(), "Expected empty list when no passengers are found for booking ID 100");
	    }

	    
	
}
