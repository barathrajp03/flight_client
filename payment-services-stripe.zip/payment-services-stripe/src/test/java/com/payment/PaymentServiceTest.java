package com.payment;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import static org.mockito.ArgumentMatchers.any;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.any;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Value;

import com.payment.entity.Payment;
import com.payment.repository.PaymentRepository;
import com.payment.service.PaymentService;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.net.RequestOptions;

public class PaymentServiceTest {
		

    @Mock
    private PaymentRepository paymentRepository;

    @InjectMocks
    private PaymentService paymentService;

    @Value("sk_test_51PZRXk2KxuVRK9r9Uv9Udmz8jTQIzoDLHCgsrOOGNmSFGmdThBhpa6Hqp51xj2gFrn6qnk121W5jn19YA6o546QF00JRuarOx7")
    private String stripeApiKey;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testProcessPayment_Success() throws StripeException {
        // Mock Stripe API call
        RequestOptions requestOptions = RequestOptions.builder().setApiKey(stripeApiKey).build();

        Map<String, Object> params = new HashMap<>();
        params.put("amount", 10000); // Amount in cents (INR 100)
        params.put("currency", "INR");
        params.put("payment_method_types", new String[]{"card"});

        PaymentIntent mockPaymentIntent = new PaymentIntent();
        mockPaymentIntent.setId("mock_payment_intent_id");

        when(PaymentIntent.create(params, requestOptions)).thenReturn(mockPaymentIntent);

        
        // Prepare test data
        String userEmail = "test@example.com";
        double amount = 100.0;

        
        // Call the service method
        Payment result = paymentService.processPayment(userEmail, amount);

        
        // Verify the result
        assertNotNull(result);
        assertEquals(userEmail, result.getUserEmail());
        assertEquals(LocalDate.now(), result.getPaymentDate());
        assertEquals(amount, result.getAmount());
        assertTrue(result.isPaymentSuccessful());
    }
	    
	    
	    
}
