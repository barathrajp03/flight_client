package com.payment.service;

import com.payment.entity.Payment;
import com.payment.repository.PaymentRepository;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.net.RequestOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Value("${stripe.apiKey}")
    private String stripeApiKey;

    public Payment processPayment(String userEmail, double amount) throws StripeException {
        RequestOptions requestOptions = RequestOptions.builder().setApiKey(stripeApiKey).build();

        Map<String, Object> params = new HashMap<>();
        params.put("amount", (int)(amount * 100)); // amount in cents
        params.put("currency", "INR");
        params.put("payment_method_types", new String[]{"card"});

        PaymentIntent paymentIntent = PaymentIntent.create(params, requestOptions);

        Payment payment = new Payment();
        payment.setUserEmail(userEmail);
        payment.setPaymentDate(LocalDate.now());
        payment.setAmount(amount);
        payment.setPaymentSuccessful(true);

        return paymentRepository.save(payment);
    }
}

