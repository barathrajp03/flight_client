package com.payment.exception;

public class PaymentException {

}
