package com.payment.controller;

import com.payment.entity.Payment;
import com.payment.service.PaymentService;
import com.stripe.exception.StripeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payment")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/process/{userEmail}/{amount}")
    public Payment processPayment(@PathVariable String userEmail, @PathVariable double amount) throws StripeException {
        return paymentService.processPayment(userEmail, amount);
    }
}