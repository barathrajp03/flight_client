package com.login.exception;

public class InvalidCredentialException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidCredentialException(String str) {
		super(str);
	}
}
