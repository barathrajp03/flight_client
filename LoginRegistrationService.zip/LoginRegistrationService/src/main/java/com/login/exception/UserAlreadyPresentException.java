package com.login.exception;

public class UserAlreadyPresentException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserAlreadyPresentException(String str) {
		super(str);
	}
	
}
