package com.login.controller;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.login.dto.AuthDto;
import com.login.dto.UserDto;
import com.login.exception.InvalidCredentialException;
import com.login.exception.UserAlreadyPresentException;
import com.login.model.User;
import com.login.security.Jwtutil;
import com.login.service.UserServiceImpl;

import jakarta.validation.Valid;

@RestController
@Validated
@RequestMapping("/api/user")

public class UserController {
	Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserServiceImpl userService;

	@Autowired
	private Jwtutil jwtutil;

	@PostMapping("/register")
	public ResponseEntity<String> registerUser(@RequestBody @Valid User user) throws UserAlreadyPresentException {
		// user.setId(userService.genrateUniqueRandomId());
		if (userService.registerUser(user)) {

			if (user.getRole().equalsIgnoreCase("User")) {
				return new ResponseEntity<String>("Customer added successfully!!!", HttpStatus.OK);
			}
			return new ResponseEntity<String>("Admin added successfully!!!", HttpStatus.OK);

		} else {
			return new ResponseEntity<String>("Something went worng!!!", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping("/login")
	public ResponseEntity<Object> loginUser(@RequestBody @Valid AuthDto loginUser) throws InvalidCredentialException {
		System.err.println(loginUser);
		String s=userService.login(loginUser);
		return generateResponse("Logged in bro",HttpStatus.OK, loginUser, s);
	}

	@GetMapping("/validate")
	public ResponseEntity<String> validate(@RequestParam("token") String token) {
		jwtutil.validateToken(token);
		return ResponseEntity.ok("Token is valid");

	}

	@GetMapping("/getUser/{userEmailId}")
    public ResponseEntity<UserDto> getUserEmailId(@PathVariable String userEmailId){
    	
    	System.out.println("hello world");
    	
        //return new ResponseEntity<>(userService.getUser(userName),HttpStatus.OK);
    	return ResponseEntity.ok(userService.getUser(userEmailId));
    }

	

	private ResponseEntity<Object> generateResponse(String message, HttpStatus httpStatus, Object responseObj,
			String token) {
		Map<String, Object> map = new HashMap<>();
		map.put("Message", message);
		map.put("Status", httpStatus.value());
		map.put("Data", responseObj);
		map.put("Token", token);

		return new ResponseEntity<>(map, httpStatus);
	}

}
