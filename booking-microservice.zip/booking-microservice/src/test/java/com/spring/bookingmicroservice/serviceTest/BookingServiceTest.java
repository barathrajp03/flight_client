package com.spring.bookingmicroservice.serviceTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.spring.bookingmicroservice.dto.*;
import com.spring.bookingmicroservice.entity.Booking;
import com.spring.bookingmicroservice.exception.*;
import com.spring.bookingmicroservice.feign.FlightFeign;
import com.spring.bookingmicroservice.feign.PassengerFeign;
import com.spring.bookingmicroservice.feign.PaymentFeign;
import com.spring.bookingmicroservice.feign.UserFeign;
import com.spring.bookingmicroservice.repository.BookingRepository;
import com.spring.bookingmicroservice.service.BookingServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
public class BookingServiceTest {

    @Mock
    private BookingRepository bookingRepository;

    @Mock
    private FlightFeign flightFeign;

    @Mock
    private PassengerFeign passengerFeign;

    @Mock
    private UserFeign userFeign;
    
    @Mock
    private PaymentFeign paymentFeign;

    @InjectMocks
    private BookingServiceImpl bookingService;

    private Booking booking;
    private Flight flight;
    private User user;
    private Payment payment;
    private Passenger passenger;

    @BeforeEach
    void setUp() {
        booking = new Booking();
        booking.setBookingId(1);
        booking.setFlightId(1);
        booking.setUserName("testUser");
        booking.setNoOfPersons(2);
        booking.setSeatNumbers(List.of("1A", "1B"));
        booking.setBookingDate(LocalDate.now());

        flight = new Flight();
        flight.setFlightId(1);
        flight.setAvilableSeats(10);
        flight.setSeatNumbers(List.of("1A", "1B", "2A", "2B"));
        flight.setPrice(100.0);

        user = new User();
        user.setEmail("test@example.com");

        payment = new Payment();
        payment.setPaymentSuccessful(true);

        passenger = new Passenger();
        passenger.setPassengerId(1);
        passenger.setBookingId(1);
        passenger.setSeatName("1A");
    }
    
    /*
    @Test
    public void testBookFlight_Success() throws Exception, UserNameNotFoundException {
        when(flightFeign.viewByFlightId(1)).thenReturn(flight);
        when(userFeign.getUser("testUser")).thenReturn(user);
        when(paymentFeign.processPayment(user.getEmail(), 200.0)).thenReturn(payment);
        when(bookingRepository.save(any(Booking.class))).thenReturn(booking);
        when(passengerFeign.addPassengersByBookingId(anyList(), eq(1))).thenReturn(List.of(passenger, passenger));

        Booking result = bookingService.bookFlight(booking);

        assertNotNull(result);
        assertEquals(booking, result);
        verify(flightFeign).update(anyInt(), any(Flight.class));
    }
    */

    @Test
    public void testBookFlight_Failure_InsufficientSeats() {
        flight.setAvilableSeats(1);
        when(flightFeign.viewByFlightId(1)).thenReturn(flight);

        BookingFailedException exception = assertThrows(BookingFailedException.class,
                () -> bookingService.bookFlight(booking));

        assertEquals("insufficient seats", exception.getMessage());
    }

    /*
    @Test
    public void testBookFlight_Failure_PaymentFailed() throws Exception {
        when(flightFeign.viewByFlightId(1)).thenReturn(flight);
        when(userFeign.getUser("testUser")).thenReturn(user);
        payment.setPaymentSuccessful(false);
        when(paymentFeign.processPayment(user.getEmail(), 200.0)).thenReturn(payment);

        BookingFailedException exception = assertThrows(BookingFailedException.class,
                () -> bookingService.bookFlight(booking));

        assertEquals("Payment failed", exception.getMessage());
    }
	*/
	
    @Test
    public void testBookFlight_Failure_SeatAlreadyBooked() throws Exception {
        flight.setSeatNumbers(List.of("2A", "2B")); // Only available seats are 2A and 2B
        when(flightFeign.viewByFlightId(1)).thenReturn(flight);

        BookingFailedException exception = assertThrows(BookingFailedException.class,
                () -> bookingService.bookFlight(booking));

        assertEquals("The seat is already booked", exception.getMessage());
    }

    @Test
    public void testBookFlight_Failure_NoOfPersonsMismatch() {
        booking.setSeatNumbers(List.of("1A")); // Mismatch between noOfPersons and seatNumbers
        when(flightFeign.viewByFlightId(1)).thenReturn(flight);

        BookingFailedException exception = assertThrows(BookingFailedException.class,
                () -> bookingService.bookFlight(booking));

        assertEquals("the no of person is not equal to no of seat numbers", exception.getMessage());
    }
    
    @Test
    public void testTotalCostOfTickets_Success() throws Exception {
        double cost = bookingService.totalCostOfTickets(flight, 2);
        assertEquals(200.0, cost);
    }

    /*
    @Test
    public void testTotalCostOfTickets_Failure_FlightNotFound() {
        Flight nullFlight = null;
        BookingFailedException exception = assertThrows(BookingFailedException.class,
                () -> bookingService.totalCostOfTickets(nullFlight, 2));
        assertEquals("Flight not found with this flight id", exception.getMessage());
    }
    */
    	
    @Test
    public void testTotalCostOfTickets_Success1() throws Exception {
        double cost = bookingService.totalCostOfTickets(flight, 2);
        assertEquals(200.0, cost);
    }

    /*
    @Test
    public void testTotalCostOfTickets_Failure_FlightNotFound1() {
        Flight nullFlight = null;
        BookingFailedException exception = assertThrows(BookingFailedException.class,
                () -> bookingService.totalCostOfTickets(nullFlight, 2));
        assertEquals("Flight not found with this flight id", exception.getMessage());
    }
    */
    
    @Test
    public void testGetBookingById_Success() throws Exception {
        when(bookingRepository.findById(1)).thenReturn(Optional.of(booking));
        when(passengerFeign.getPassengersListByBookingId(1)).thenReturn(List.of(passenger, passenger));

        Booking result = bookingService.getBookingById(1);

        assertNotNull(result);
        assertEquals(booking, result);
    }

    /*
    @Test
    public void testGetBookingById_Failure_BookingNotFound() {
        when(bookingRepository.findById(1)).thenReturn(Optional.empty());

        Exception exception = assertThrows(InvalidBookingException.class,
                () -> bookingService.getBookingById(1));

        assertEquals("please specify correct booking id", exception.getMessage());
    }
    
    */

    /*
    @Test
    public void testDeleteByPassengerId_Success() throws Exception {
        when(passengerFeign.deletePassenger(1)).thenReturn(passenger);
        when(bookingRepository.findById(1)).thenReturn(Optional.of(booking));
        when(flightFeign.viewByFlightId(1)).thenReturn(flight);
        when(bookingRepository.save(any(Booking.class))).thenReturn(booking);

        Passenger result = bookingService.deleteByPassengerId(1);

        assertNotNull(result);
        assertEquals(passenger, result);
        verify(flightFeign).update(anyInt(), any(Flight.class));
        verify(flightFeign).CancelFlightSeats(1);
    }
    
    */
    /*
    @Test
    public void testDeleteByPassengerId_Failure_BookingNotFound() {
        when(passengerFeign.deletePassenger(1)).thenReturn(passenger);
        when(bookingRepository.findById(1)).thenReturn(Optional.empty());

        BookingCancellationFailedException exception = assertThrows(BookingCancellationFailedException.class,
                () -> bookingService.deleteByPassengerId(1));

        assertEquals("booking cancelation is failed", exception.getMessage());
    }
    
    */
    
    
    @Test
    public void testGetBookingById_Success1() throws Exception {
        when(bookingRepository.findById(1)).thenReturn(Optional.of(booking));
        when(passengerFeign.getPassengersListByBookingId(1)).thenReturn(List.of(passenger, passenger));

        Booking result = bookingService.getBookingById(1);

        assertNotNull(result);
        assertEquals(booking, result);
    }

    /*
    @Test
    public void testGetBookingById_Failure_BookingNotFound1() {
        when(bookingRepository.findById(1)).thenReturn(Optional.empty());

        InvalidBookingException exception = assertThrows(InvalidBookingException.class,
                () -> bookingService.getBookingById(1));

        assertEquals("please specify correct booking id", exception.getMessage());
    }

	*/
    
    
}
