package com.spring.bookingmicroservice.controller;


import com.spring.bookingmicroservice.dto.Passenger;
import com.spring.bookingmicroservice.entity.Booking;
import com.spring.bookingmicroservice.exception.*;
import com.spring.bookingmicroservice.service.BookingService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/booking")
public class BookingController {

    @Autowired
    BookingService bookingService;

    @PostMapping("/bookFlight")
    public ResponseEntity<Booking> bookFlight(@RequestBody Booking booking) throws UserNameNotFoundException, Exception {

        return new ResponseEntity<Booking>(bookingService.bookFlight(booking), HttpStatus.OK);

    }
    
    @GetMapping("/getByBookingId/{bookingId}")
	public Booking getBookingById(@PathVariable("bookingId") int bookingId) throws InvalidBookingException, Exception {
		return bookingService.getBookingById(bookingId);
	}
	
	@GetMapping("/getByFlightId/{flightId}")
	public List<Booking> getBookingsByFlightId(@PathVariable("flightId") int flightId) throws Exception{
		return bookingService.getBookingByFlightId(flightId);
	}
	
	@DeleteMapping("/deleteByPassengerId/{passengerId}")
	public Passenger CancelBooking(@PathVariable("passengerId") int passengerId) throws BookingCancellationFailedException {
		return bookingService.deleteByPassengerId(passengerId);
	}
   

}
