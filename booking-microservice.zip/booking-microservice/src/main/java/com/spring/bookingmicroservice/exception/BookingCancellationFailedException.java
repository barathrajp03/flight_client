package com.spring.bookingmicroservice.exception;

public class BookingCancellationFailedException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BookingCancellationFailedException(String s) {
        super(s);
    }
}
