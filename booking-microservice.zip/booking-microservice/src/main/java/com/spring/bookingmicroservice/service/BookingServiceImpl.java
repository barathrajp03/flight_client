package com.spring.bookingmicroservice.service;

import com.spring.bookingmicroservice.dto.*;
import com.spring.bookingmicroservice.entity.Booking;
import com.spring.bookingmicroservice.exception.*;
import com.spring.bookingmicroservice.feign.FlightFeign;
import com.spring.bookingmicroservice.feign.PassengerFeign;
import com.spring.bookingmicroservice.feign.PaymentFeign;
import com.spring.bookingmicroservice.feign.UserFeign;
import com.spring.bookingmicroservice.repository.BookingRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.Collections;

import java.util.List;
import java.util.Optional;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	BookingRepository bookingRepository;

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	FlightFeign flightFeign;

	@Autowired
	PassengerFeign passengerFeign;

	@Autowired
	UserFeign userFeign;
	
	@Autowired
	PaymentFeign paymentFeign;
	


	// Method to book a flight
	@Override
	public Booking bookFlight(Booking booking) throws UserNameNotFoundException, Exception {

		System.out.println("Method Called");
		
		System.err.println(booking);
		
		System.out.println("hello barath");

		booking.setBookingDate(LocalDate.now());

		Integer flightId = booking.getFlightId();

		Flight f = flightFeign.viewByFlightId(flightId);
		
		System.out.println(f);

		System.out.println(booking.getUserEmailId());
		if (f.getAvilableSeats() < booking.getNoOfPersons()) {

			throw new BookingFailedException("insufficient seats");
		}

		if (booking.getNoOfPersons() == booking.getSeatNumbers().size()) {

			List<String> seatNumbers = booking.getSeatNumbers();

//			f.setSeatNumbers(seatNumbers);
			System.err.println(seatNumbers);

			double totalCost = totalCostOfTickets(f, booking.getNoOfPersons());
			booking.setTotalCost(totalCost);
			System.err.println(totalCost);
			
			
			User user = userFeign.getUser(booking.getUserEmailId());
			
			System.out.println(user);
			
			List<String> fetchedSeatNumbers = f.getSeatNumbers();
			
			System.err.println(fetchedSeatNumbers);
			   
			   for(String seat:seatNumbers) {
				   
				   if(fetchedSeatNumbers.contains(seat)) {
					   
					   fetchedSeatNumbers.remove(seat);
				   }else {
					   throw new BookingFailedException("The seat is already booked");
				   }
			   }
			   
			   f.setAvilableSeats(f.getAvilableSeats()-booking.getNoOfPersons());
			
			   Payment payment = paymentFeign.processPayment(user.getEmail(), totalCost);
				 
				    System.out.println(payment);
			        if (!payment.isPaymentSuccessful()) {
			            throw new BookingFailedException("Payment failed");
			        }
			        
			        System.out.println("sdfghjkljhfdslkgfdkj");
			        Booking book = bookingRepository.save(booking);   
			        System.out.println(book);
			
			Flight ff = flightFeign.update(flightId, f);
			System.out.println(ff);
			
			List<Passenger> passengerList = passengerFeign.addPassengersByBookingId(booking.getPassengerList(),
					booking.getBookingId());
			booking.setPassengerList(passengerList);
		}
		else {
			throw new BookingFailedException("the no of person is not equal to no of seat numbers");
		}

		return booking;


	}

	@SuppressWarnings("unused")
	@Override
	public double totalCostOfTickets(Flight f, Integer noOfPersons) throws BookingFailedException {
		// TODO Auto-generated method stub

		/*
		Integer flightId = f.getFlightId();
		if (f == null) {
			throw new BookingFailedException("Flight not found with this flight id");
		}
		*/
		
		
		Integer flightId = f.getFlightId();
		if (f == null) {
			throw new BookingFailedException("Flight not found with this flight id");
		}
		double price = f.getPrice() * noOfPersons;
		System.out.println(price);

		return price;
	}

	@Override
	public Booking getBookingById(int bookingId) throws Exception {
		// TODO Auto-generated method stub

		Optional<Booking> bookingObj = bookingRepository.findById(bookingId);
		Booking b = bookingObj.get();

		if (b == null) {
			throw new InvalidBookingException("please specify correct booking id");
		}
		b.setPassengerList(passengerFeign.getPassengersListByBookingId(bookingId));
		return b;
	}

	@Override
	public List<Booking> getBookingByFlightId(int flightId) throws Exception {
		// TODO Auto-generated method stub
		List<Booking> bookingList = bookingRepository.findByFlightId(flightId);
		if (bookingList.isEmpty()) {
			throw new Exception("Invalid flight id");

		}
		return bookingList;
	}

	@Override
	public Passenger deleteByPassengerId(int passengerId) throws BookingCancellationFailedException {
		// TODO Auto-generated method stub

		Passenger passengerToDelete = passengerFeign.deletePassenger(passengerId);
		System.out.println("I am printing ");

		System.out.println(passengerToDelete);
		
		String seatName = passengerToDelete.getSeatName();
		

		// Passenger passenger = passengerFeign.getPassengerByPassengerId(passengerId);
		// System.out.println(passenger);

		int id = passengerToDelete.getBookingId();
		System.out.println(id);

		Booking book = bookingRepository.findById(id).get();
		
		System.out.println(book);
		
		if(book==null) {
			throw new BookingCancellationFailedException("booking cancelation is failed");
		}
		System.err.println(book);
		book.setNoOfPersons(book.getNoOfPersons() - 1);
		
		bookingRepository.save(book);

		Integer flightId = book.getFlightId();
		
		System.out.println(flightId);
		Flight flight = flightFeign.viewByFlightId(flightId);
		
		List<String> l = flight.getSeatNumbers();
		l.add(seatName);
		Collections.sort(l);
		flight.setSeatNumbers(l);
		flightFeign.update(flightId, flight);
		
		
		flightFeign.CancelFlightSeats(flightId);

		return null;

	}

	/*
	 * If checked in we must make a rest call to check in service to restore the
	 * number of cancelled seats and seat numbers else simple deleting the booking
	 * from db
	 */

}
