package com.spring.bookingmicroservice.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.spring.bookingmicroservice.dto.Passenger;



@FeignClient(name="passenger-service", url = "http://localhost:8087/passenger")
public interface PassengerFeign {

	
	@PostMapping("/add/{bookingId}")
	public List<Passenger> addPassengersByBookingId(@RequestBody List<Passenger> passengersList,@PathVariable int bookingId );
	
	@GetMapping("/get/{bookingId}")
	public List<Passenger> getPassengersListByBookingId(@PathVariable int bookingId);
	
	@GetMapping("/getByPassengerId/{passengerId}")
	public Passenger getPassengerByPassengerId(@PathVariable int passengerId);
	
	@DeleteMapping("/delete/{passengerId}")
	public Passenger deletePassenger(@PathVariable int passengerId);
	
}
