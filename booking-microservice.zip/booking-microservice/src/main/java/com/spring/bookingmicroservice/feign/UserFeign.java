package com.spring.bookingmicroservice.feign;

import org.springframework.cloud.openfeign.FeignClient;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

//import com.login.dto.UserDto;
import com.spring.bookingmicroservice.dto.User;

@FeignClient(name="LoginRegistrationService", url="http://localhost:8085/api/user")
public interface UserFeign {

	    
	
	 	@GetMapping("/getUser/{userEmailId}")
	    public User getUser(@PathVariable String userEmailId);
}
