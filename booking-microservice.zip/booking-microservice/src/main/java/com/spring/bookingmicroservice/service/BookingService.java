package com.spring.bookingmicroservice.service;


import com.spring.bookingmicroservice.dto.Flight;
import com.spring.bookingmicroservice.dto.Passenger;
import com.spring.bookingmicroservice.entity.Booking;
import com.spring.bookingmicroservice.exception.*;

import java.util.List;

public interface BookingService {

    Booking bookFlight(Booking booking) throws BookingFailedException, UserNameNotFoundException, Exception;
    
    
    Booking getBookingById(int id) throws InvalidBookingException, Exception;
    
    List<Booking> getBookingByFlightId(int flightId) throws Exception;
    
    Passenger deleteByPassengerId(int passengerId) throws BookingCancellationFailedException;
    
    double totalCostOfTickets(Flight f, Integer noOfPersons) throws BookingFailedException;

}
