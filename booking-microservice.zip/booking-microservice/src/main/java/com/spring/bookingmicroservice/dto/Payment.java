package com.spring.bookingmicroservice.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Payment {
	
	private Long paymentId;
    private String userEmail;
    private LocalDate paymentDate;
    private double amount;
    private boolean isPaymentSuccessful;

}
