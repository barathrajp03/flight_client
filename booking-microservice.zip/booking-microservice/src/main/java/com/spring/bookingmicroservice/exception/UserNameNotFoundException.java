package com.spring.bookingmicroservice.exception;

public class UserNameNotFoundException extends Throwable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserNameNotFoundException(String userWithUsernameNotFound) {
        super(userWithUsernameNotFound);
    }
}
