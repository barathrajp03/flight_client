package com.spring.bookingmicroservice.exception;

public class InvalidBookingException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidBookingException(String bookingIsInvalid) {
        super(bookingIsInvalid);
    }

}
