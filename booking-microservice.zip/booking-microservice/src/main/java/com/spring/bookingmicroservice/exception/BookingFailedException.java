package com.spring.bookingmicroservice.exception;

public class BookingFailedException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BookingFailedException(String s) {
        super(s);
    }
}
