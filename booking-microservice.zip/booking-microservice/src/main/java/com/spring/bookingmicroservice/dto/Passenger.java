package com.spring.bookingmicroservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Passenger {

	private int passengerId;
	private String firstName;
	private String lastName;
	private String age;
	private String gender;
	private String mailId;
	private String phoneNumber;
	private String passportNumber;
	private String seatName;
	private int bookingId;
	
}
