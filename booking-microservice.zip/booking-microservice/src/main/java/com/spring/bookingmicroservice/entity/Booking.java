package com.spring.bookingmicroservice.entity;

import java.time.LocalDate;
import java.util.List;

import com.spring.bookingmicroservice.dto.Passenger;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;

import lombok.NoArgsConstructor;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Booking {

	  @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private int bookingId;
	    
	    @NotNull(message = "Flight ID cannot be null")
	    private Integer flightId;
	    
	    @NotBlank(message = "User name cannot be empty")
	    private String UserEmailId;
	    
	    private Boolean bookingStatus;
	    //private Boolean checkInStatus=false;
	    //private String checkInId;
	    
	    @NotNull(message = "Number of persons cannot be null")
	    @Min(value = 1, message = "Number of persons must be at least 1")
	    private Integer noOfPersons;
	    
	    
	    private LocalDate bookingDate;
	    private double totalCost;
	    
	    @NotEmpty(message = "Seat numbers cannot be empty")
	    private List<String> seatNumbers;

	    @Transient
	    private List<Passenger> passengerList;
	    
    
    
}
