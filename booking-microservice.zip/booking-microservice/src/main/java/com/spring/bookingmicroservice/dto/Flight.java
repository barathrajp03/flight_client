package com.spring.bookingmicroservice.dto;

import java.time.LocalDate;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Flight {
   
	
	private Integer flightId;
	private String flightName;
	private Integer totalSeats;
	private String source;
	private String destination;
	private LocalDate date;
	private Double price;	
	private String departure;	
	private String arrival;	
	//private List<String> seatNumbers=List.of("A101","A102","A103","A104","A105","A106","A107","A108","A109","A110");
	private List<String> seatNumbers;
	private Integer avilableSeats;
}
