package com.spring.bookingmicroservice.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.spring.bookingmicroservice.dto.Payment;

@FeignClient(name = "payment-services-stripe", url = "http://localhost:8088/payment")
public interface PaymentFeign {

	@PostMapping("/process/{userEmail}/{amount}")
	Payment processPayment(@PathVariable String userEmail, @PathVariable double amount);
}
