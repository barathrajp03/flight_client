package com.spring.bookingmicroservice.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.spring.bookingmicroservice.dto.Flight;



@FeignClient(name="FLIGHT-SERVICE", url="http://localhost:8081/flightAdmin")
public interface FlightFeign {
	
	
	@PutMapping("/update/{flightId}")
	public Flight update(@PathVariable int flightId,@RequestBody Flight  f);
	
	@GetMapping("/viewByFlightId/{flightId}")
	public Flight viewByFlightId(@PathVariable int flightId);
	
	@PutMapping("/cancelSeats/{flightId}")
	public ResponseEntity<Flight> CancelFlightSeats(@PathVariable Integer flightId);
	
}
