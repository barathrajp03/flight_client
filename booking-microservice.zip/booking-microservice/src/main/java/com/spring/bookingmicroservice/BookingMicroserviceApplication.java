package com.spring.bookingmicroservice;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.reactive.function.client.WebClient;

@SpringBootApplication
@EnableFeignClients
@EnableDiscoveryClient
@EnableJpaRepositories(basePackages = "com.spring.bookingmicroservice.repository")
//@ComponentScan(basePackages = "com.spring.bookingmicroservice")
//@EntityScan(basePackages = "com.*")
public class BookingMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookingMicroserviceApplication.class, args);
	}

    @Bean
    ModelMapper getModelMapper() {
		return new ModelMapper();
	}
    
    @Bean
    WebClient webClient(){
		return WebClient.builder().build();
	}

}
