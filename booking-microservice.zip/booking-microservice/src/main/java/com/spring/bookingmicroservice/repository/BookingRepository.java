package com.spring.bookingmicroservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.bookingmicroservice.entity.Booking;

import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Integer> {

    //List<Booking> findByUserName(String userName);
    List<Booking> findByFlightId(int flightId);

}
