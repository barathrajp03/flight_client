import { Component } from '@angular/core';

@Component({
  selector: 'app-passenger',
  standalone: true,
  imports: [],
  templateUrl: './passenger.component.html',
  styleUrl: './passenger.component.css'
})
export class PassengerComponent {

}
