export interface Payment{
    paymentId:number;
    userEmail:string;
    paymentDate:string;
    amount:number;
    isPaymentSuccessful:boolean;
}