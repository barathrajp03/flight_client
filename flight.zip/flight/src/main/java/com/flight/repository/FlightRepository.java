package com.flight.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flight.entity.Flight;


public interface FlightRepository extends JpaRepository<Flight, Integer>{

	List<Flight> findByFlightName(String flightName);
	
	List<Flight> findBySourceAndDestinationAndDate(String source, String destination, LocalDate date);


}
