package com.flight.controller;

import java.time.LocalDate;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.flight.entity.Flight;
import com.flight.exception.FlightNotFoundException;
import com.flight.service.FlightService;

import jakarta.validation.Valid;

@RestController //define a class as a RESTful web service controller
@RequestMapping("/flightAdmin") //to map HTTP requests to specific methods in a controller.
public class AdminFlightController {
	
	
	@Autowired
	FlightService service;
	
	
	//Endpoint Adding the flight details.
	@PostMapping("/add")
	public ResponseEntity<Flight> addFlight(@Valid @RequestBody Flight flight) {
	//ResponseEntity allows you to build and customize responses for various situations, such as success responses, error responses, conditional responses
		
		service.addFlight(flight);
		
		return new ResponseEntity<Flight>(flight, HttpStatus.OK);
	}
	
	
	//Endpoint for Deleting Flight by Id
	@DeleteMapping("/delete/{flightId}")
	public ResponseEntity<String> deleteFlight(@PathVariable int flightId) throws FlightNotFoundException {
		
		String msg=service.deleteFlight(flightId);
		
		return new ResponseEntity<>( msg,HttpStatus.OK);
	}
	
	
	//Endpoint to view all flights
	@GetMapping("/viewAll")
	public ResponseEntity<List<Flight>> viewFlights(){
		
		List<Flight> allFlights=service.viewAllFlight();
		
		return new ResponseEntity<List<Flight>>(allFlights, HttpStatus.OK);
		
	}
	
	
	//Endpoint for searching Flights based on source and destination.
	@GetMapping("/search/{source}/{destination}")
	public ResponseEntity<List<Flight>> search(@PathVariable String source,@PathVariable String destination) throws FlightNotFoundException{
		
		List<Flight> flights= service.searchFlight(source, destination);
		
		return new ResponseEntity<List<Flight>>(flights, HttpStatus.OK);
	}
	
	
	
	@GetMapping("/search/{source}/{destination}/{date}")
	public ResponseEntity<List<Flight>> searchBySourceAndDestinationAndDate(@PathVariable String source,@PathVariable String destination, @PathVariable LocalDate date) throws FlightNotFoundException{
		
		List<Flight> flights= service.searchFlightBySourceAndDestinationAndDate(source, destination, date);
		
		return new ResponseEntity<List<Flight>>(flights, HttpStatus.OK);
	}

	
	//Endpoint to Update flight by flightId
	@PutMapping("/update/{flightId}")
	public ResponseEntity<Flight> update(@PathVariable int flightId,@RequestBody Flight  f) throws FlightNotFoundException {
		
		@SuppressWarnings("unused")
		List<String> seatNumbers = f.getSeatNumbers();
		System.err.println("here "+f);
		 Flight flight=service.updateFlight(flightId,f);
		 System.err.println("cant be here");
		 return new ResponseEntity<Flight> (flight,HttpStatus.OK);

	}
	
	//Endpoint  to view flight by FlightName
	@GetMapping("/viewByFlightName/{flightName}")
	public ResponseEntity<List<Flight>> viewByFlightName(@PathVariable String flightName) throws FlightNotFoundException{
		
		List<Flight> viewByName=service.viewFlightsByFlightName(flightName);
		 
		return new ResponseEntity<List<Flight>>(viewByName,HttpStatus.OK);
	}
	
	
	//Endpoint  to view flight by FlightId
	@GetMapping("/viewByFlightId/{flightId}")
	public ResponseEntity<Flight> viewByFlightId(@PathVariable int flightId) throws FlightNotFoundException{
		
		Flight viewById=service.viewFlightsByFlightId(flightId);
		
		return new ResponseEntity<Flight>(viewById,HttpStatus.OK);
	}
	
	
	@GetMapping("/getSeatNumbers/{flightId}")
	public ResponseEntity<Integer> getSeatNumbers(@PathVariable int flightId) throws FlightNotFoundException{
		
		int seats=service.getSeats(flightId);
		
		return new ResponseEntity<Integer>(seats,HttpStatus.OK);
	
	}

	@PutMapping("/restoreFlightSeats/{flightId}")
	public ResponseEntity<Flight> restoreFlightSeats(@PathVariable Integer flightId,@RequestBody List<String> seatNumbers) throws FlightNotFoundException {
		
		return new ResponseEntity<>(service.restoreSeats(flightId,seatNumbers),HttpStatus.OK);
	
	}
	
	@PutMapping("/cancelSeats/{flightId}")
	public ResponseEntity<Flight> CancelFlightSeats(@PathVariable Integer flightId) throws FlightNotFoundException {
		
		return new ResponseEntity<>(service.cancelSeats(flightId),HttpStatus.OK);
	
	}
	
	
	 @PutMapping("/updateFlightByFlightId/{flightId}")
	    public ResponseEntity<Flight> updateFlight(@PathVariable int flightId, @RequestBody Flight updatedFlight) {
	        try {
	            Flight updated = service.updateFlightByFlightId(flightId, updatedFlight);
	            return ResponseEntity.ok(updated);
	        } catch (FlightNotFoundException e) {
	            return ResponseEntity.notFound().build();
	        }
	    }

	
}
