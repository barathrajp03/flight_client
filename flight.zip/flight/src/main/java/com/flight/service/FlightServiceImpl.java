package com.flight.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.entity.Flight;
import com.flight.exception.FlightNotFoundException;
import com.flight.repository.FlightRepository;

@Service
public class FlightServiceImpl implements FlightService {

	@Autowired
	FlightRepository repository;

	// Method to add flight data into database.
	@Override
	public Flight addFlight(Flight flight) {

//		repository.save(flight);
//		
//		return flight;

		List<String> list = new ArrayList<String>();
		for (int i = 0; i <= flight.getTotalSeats() - 1; i++) {
			list.add("A" + (101 + i));
		}
		flight.setSeatNumbers(list);
		flight.setAvilableSeats(flight.getTotalSeats());
		repository.save(flight);

		return flight;
	}

	// Method to delete flight data from database by flightId
	@Override
	public String deleteFlight(int flightId) throws FlightNotFoundException {

		// checking if flight with given Id is exists or not.
		if (repository.existsById(flightId)) { // existsById- returns a boolean type

			repository.deleteById(flightId);
			return "Flight Deleted Successfully...!";
		} else {

			throw new FlightNotFoundException("Flight with ID " + flightId + " not found");
		}
	}

	// Method to view all flights
	@Override
	public List<Flight> viewAllFlight() {

		List<Flight> flight = new ArrayList<Flight>();
		// getting all the flight data and adding into the list.
		repository.findAll().forEach(flightDetails -> flight.add(flightDetails));

		return flight;
	}

	// Method to search flights based on source and destination.
	@Override
	public List<Flight> searchFlight(String source, String destination) throws FlightNotFoundException {

		List<Flight> flight = new ArrayList<Flight>();
		// getting all the flight details.
		repository.findAll().forEach(flightDetails -> flight.add(flightDetails));

		List<Flight> matchedFlights = new ArrayList<Flight>();
		// matching the flight data of given source and destination.
		matchedFlights = flight.stream().filter(
				f -> (f.getSource().equalsIgnoreCase(source) && f.getDestination().equalsIgnoreCase(destination)))
				.collect(Collectors.toList());

		if (matchedFlights.isEmpty()) {
			throw new FlightNotFoundException(
					"No flights found for source: " + source + " and destination: " + destination);
		}

		return matchedFlights;
	}

	@Override
	@org.springframework.transaction.annotation.Transactional
	public Flight updateFlight(int flightId, Flight flight) throws FlightNotFoundException {
//		repository.save(flight);
		System.err.println("roiid");

		return repository.save(flight);

	}

	// method to view flights by flightName.
	@Override
	public List<Flight> viewFlightsByFlightName(String flightName) throws FlightNotFoundException {

		System.err.println(flightName);
		List<Flight> matchedFlights = repository.findByFlightName(flightName);

		System.err.println(matchedFlights);

		if (matchedFlights.isEmpty()) {

			throw new FlightNotFoundException("No flights found with the name: " + flightName);

		}

		return matchedFlights;
	}

	@Override
	public Flight viewFlightsByFlightId(int flightId) throws FlightNotFoundException {

		Optional<Flight> matchedFlights = repository.findById(flightId);

		if (matchedFlights.isEmpty()) {

			throw new FlightNotFoundException("No flights found with the Id: " + flightId);
		}

		return matchedFlights.get();
	}

	@Override
	public List<String> getSeatNumbers(int flightId) throws FlightNotFoundException {

		Flight matchedFlights = repository.findById(flightId).get();

		if (matchedFlights == null) {

			throw new FlightNotFoundException("No flights found with the Id: " + flightId);
		}

		return matchedFlights.getSeatNumbers();

	}

	@Override
	public Integer getSeats(int flightId) throws FlightNotFoundException {

		Flight matchedFlights = repository.findById(flightId).get();

		if (matchedFlights == null) {

			throw new FlightNotFoundException("No flights found with the Id: " + flightId);
		}

		return matchedFlights.getTotalSeats();

	}

	@Override
	public Flight restoreSeats(int flightId, List<String> seatNumbers) throws FlightNotFoundException {

		Optional<Flight> optionalFlight = repository.findById(flightId);

		if (optionalFlight.isPresent()) {

			Flight flight = optionalFlight.get();

			// Getting seatNumbers and seat count from Flight db
			List<String> fetchedSeats = flight.getSeatNumbers();
			Integer seatCount = flight.getTotalSeats();

			// Adding cancelled seats back into the list
			fetchedSeats.addAll(seatNumbers);

			// Setting new value of restored seat count and seat numbers
			flight.setTotalSeats(seatCount + seatNumbers.size());
			flight.setSeatNumbers(fetchedSeats);

			return repository.save(flight);

		}

		throw new FlightNotFoundException("Flight with id " + flightId + " not found");

	}

	@Override
	public List<Flight> searchFlightBySourceAndDestinationAndDate(String source, String destination, LocalDate date)
			throws FlightNotFoundException {

		List<Flight> matchedFlights = repository.findBySourceAndDestinationAndDate(source, destination, date);

		if (matchedFlights.isEmpty()) {
			throw new FlightNotFoundException(
					"No flights found for source: " + source + " and destination: " + destination + " on that day");
		}

		return matchedFlights;

	}

	@Override
	public Flight cancelSeats(int flightId) {

		Optional<Flight> flight = repository.findById(flightId);

		Flight flightObj = flight.get();
		flightObj.setAvilableSeats(flightObj.getAvilableSeats() + 1);
		repository.save(flightObj);

		return flightObj;
	}

	@Override
	public Flight updateFlightByFlightId(int flightId,Flight fObj) throws FlightNotFoundException {
		// TODO Auto-generated method stub

		Optional<Flight> existingFlight = repository.findById(flightId);
		if (existingFlight.isEmpty()) {
			throw new FlightNotFoundException("Flight is not found with this id " + flightId);
		}
		
		 Flight existingFlightToUpdate = existingFlight.get();
	        // Update only the fields that are allowed to be updated
		 existingFlightToUpdate.setFlightName(fObj.getFlightName());
		 existingFlightToUpdate.setTotalSeats(fObj.getTotalSeats());
		 existingFlightToUpdate.setSource(fObj.getSource());
		 existingFlightToUpdate.setDestination(fObj.getDestination());
		 existingFlightToUpdate.setDate(fObj.getDate());
		 existingFlightToUpdate.setPrice(fObj.getPrice());
		 existingFlightToUpdate.setDeparture(fObj.getDeparture());
		 existingFlightToUpdate.setArrival(fObj.getArrival());
		 existingFlightToUpdate.setSeatNumbers(fObj.getSeatNumbers());
		 existingFlightToUpdate.setAvilableSeats(fObj.getAvilableSeats());

	        return repository.save(existingFlightToUpdate);
	    }
	   

}
