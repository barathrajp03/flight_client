package com.flight.service;

import java.time.LocalDate;
import java.util.List;

import com.flight.entity.Flight;
import com.flight.exception.FlightNotFoundException;


public interface FlightService {
	
	
	
	Flight addFlight(Flight flight);
	
	String deleteFlight(int flightId) throws FlightNotFoundException;
	
	List<Flight> viewAllFlight();
	
	List<Flight> searchFlight(String source,String destination) throws FlightNotFoundException;
	
	Flight updateFlight(int flightId,Flight f) throws FlightNotFoundException;
	
	List<Flight> viewFlightsByFlightName(String flightName) throws FlightNotFoundException;

	Flight viewFlightsByFlightId(int flightId) throws FlightNotFoundException;
	
	List<String> getSeatNumbers(int flightId) throws FlightNotFoundException;

	Integer getSeats(int flightId) throws FlightNotFoundException;

	Flight restoreSeats(int flightId,List<String> seatNumbers) throws FlightNotFoundException;

	List<Flight> searchFlightBySourceAndDestinationAndDate(String source, String destination, LocalDate date)
			throws FlightNotFoundException;
	
	Flight cancelSeats(int flightId);
	
	Flight updateFlightByFlightId(int flightId,Flight fObj) throws FlightNotFoundException;

}
