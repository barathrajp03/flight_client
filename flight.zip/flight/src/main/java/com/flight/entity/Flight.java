package com.flight.entity;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//@Data // bundles the features of @ToString , @EqualsAndHashCode ,
//@Getter / @Setter and @RequiredArgsConstructor together
//@AllArgsConstructor //generates a constructor that includes parameters 
//@NoArgsConstructor
//@ToString //creates readable string representation of an object.


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Flight {

	@jakarta.persistence.Id

	private Integer flightId;
	
	@NotBlank(message = "Flight number cannot be empty")
	private String flightName;
	@NotNull(message = "Total seats cannot be null")
    @Min(value = 1, message = "Total seats must be at least 1")
    private Integer totalSeats;

//    @NotBlank(message = "Source cannot be empty")
    private String source;

    @NotBlank(message = "Destination cannot be empty")
    private String destination;

    @NotNull(message = "Date cannot be null")
//    @Future(message = "Date must be in the future")
    private LocalDate date;

    @NotNull(message = "Price cannot be null")
    @Positive(message = "Price must be positive")
    private Double price;

    @NotBlank(message = "Departure time cannot be empty")
    private String departure;

    @NotBlank(message = "Arrival time cannot be empty")
    private String arrival;

    @Column(columnDefinition = "VARBINARY(2048)")
    private List<String> seatNumbers;

    //@NotNull(message = "Available seats cannot be null")
    //@Min(value = 0, message = "Available seats cannot be negative")
    private Integer avilableSeats;
	
}












//
//
//
//
//@NotBlank(message = "Flight number cannot be empty")
//private String flightName;
//private Integer totalSeats;
//private String source;
//private String destination;
//private LocalDate date;
//private Double price;	
//private String departure;	
//private String arrival;	
////private List<String> seatNumbers=List.of("A101","A102","A103","A104","A105","A106","A107","A108","A109","A110");
//@Column(columnDefinition = "VARBINARY(2048)")
//private List<String> seatNumbers;
//private Integer avilableSeats;
