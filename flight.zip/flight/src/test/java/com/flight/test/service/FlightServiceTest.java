package com.flight.test.service;

import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;


import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;



import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.flight.entity.Flight;
import com.flight.exception.FlightNotFoundException;
import com.flight.repository.FlightRepository;
import com.flight.service.FlightServiceImpl;

public class FlightServiceTest {

	 	@Mock
	    private FlightRepository repository;

	    @InjectMocks
	    private FlightServiceImpl flightService;
	    
	    @SuppressWarnings("deprecation")
		@BeforeEach
	    public void setup() {
	        MockitoAnnotations.initMocks(this); // Initialize mocks
	    }
	    

	    @Test
	    public void testAddFlight_Success() {
	        Flight flightToAdd = new Flight();
	        flightToAdd.setFlightName("Test Flight");
	        flightToAdd.setSource("Source");
	        flightToAdd.setDestination("Destination");
	        flightToAdd.setTotalSeats(100);

	       when(repository.save(flightToAdd)).thenReturn(flightToAdd);

	        Flight addedFlight = flightService.addFlight(flightToAdd);

	        assertEquals("Test Flight", addedFlight.getFlightName());
	        assertEquals("Source", addedFlight.getSource());
	        assertEquals("Destination", addedFlight.getDestination());
	        assertEquals(100, addedFlight.getTotalSeats());
	    }
	    
	    
	    @Test
	    public void testDeleteFlight_Success() throws FlightNotFoundException {
	        int flightIdToDelete = 1;

	        when(repository.existsById(flightIdToDelete)).thenReturn(true);

	        String result = flightService.deleteFlight(flightIdToDelete);

	        assertEquals("Flight Deleted Successfully...!", result);
	        verify(repository, times(1)).deleteById(flightIdToDelete);
	    }

	    @Test
	    public void testDeleteFlight_Failure_NotFound() {
	        int flightIdToDelete = 1;

	        when(repository.existsById(flightIdToDelete)).thenReturn(false);

	        Exception exception = assertThrows(FlightNotFoundException.class,
	                () -> flightService.deleteFlight(flightIdToDelete));

	        assertEquals("Flight with ID 1 not found", exception.getMessage());
	        verify(repository, never()).deleteById(flightIdToDelete);
	    }
	
	    @Test
	    public void testUpdateFlight_Success() throws FlightNotFoundException {
	        int flightIdToUpdate = 1;
	        Flight flightToUpdate = new Flight();
	        flightToUpdate.setFlightId(flightIdToUpdate);
	        flightToUpdate.setFlightName("Updated Flight Name");

	        when(repository.existsById(flightIdToUpdate)).thenReturn(true);
	        when(repository.save(flightToUpdate)).thenReturn(flightToUpdate);

	        Flight updatedFlight = flightService.updateFlight(flightIdToUpdate, flightToUpdate);

	        assertEquals("Updated Flight Name", updatedFlight.getFlightName());
	        assertEquals(flightIdToUpdate, updatedFlight.getFlightId());
	    }
	    
	    @Test
	    public void testViewAllFlight_Success() {
	    	
	    	Flight f1 = new Flight();
	    	f1.setFlightName("Flight 1");
	    	f1.setSource("Source1");
	    	f1.setDestination("Destination1");
	    	f1.setPrice(100.0);
	    	
	    	Flight f2 = new Flight();
	    	f2.setFlightName("Flight 2");
	    	f2.setSource("Source 2");
	    	f2.setDestination("Destination 2");
	    	f2.setPrice(150.0);
	    	
	        List<Flight> mockFlights = Arrays.asList(f1,f2);

	        when(repository.findAll()).thenReturn(mockFlights);

	        List<Flight> resultFlights = flightService.viewAllFlight();

	        assertEquals(2, resultFlights.size());
	        assertEquals("Flight 1", resultFlights.get(0).getFlightName());
	        assertEquals("Flight 2", resultFlights.get(1).getFlightName());
	    }
	    
	    @Test
	    public void testDeleteFlight_Failure_NotFound1() {
	        int flightIdToDelete = 1;

	        when(repository.existsById(flightIdToDelete)).thenReturn(false);

	        Exception exception = assertThrows(FlightNotFoundException.class,
	                () -> flightService.deleteFlight(flightIdToDelete));

	        assertEquals("Flight with ID 1 not found", exception.getMessage());
	    }
	    /*
	    @Test
	    public void testUpdateFlight_Failure_NotFound() {
	        int flightIdToUpdate = 1;
	        Flight flightToUpdate = new Flight();
	        flightToUpdate.setFlightId(flightIdToUpdate);
	        flightToUpdate.setFlightName("Updated Flight Name");

	        when(repository.existsById(flightIdToUpdate+1)).thenReturn(false);

	        Exception exception = assertThrows(FlightNotFoundException.class,
	                () -> flightService.updateFlight(flightIdToUpdate, flightToUpdate));

	        assertEquals("Flight with ID 1 not found", exception.getMessage());
	    }
	    */
	    @Test
	    public void testViewFlightsByFlightName_Failure_NotFound() {
	        String flightName = "Nonexistent Flight";

	        // Mock repository behavior to return an empty list when searching by flightName
	        when(repository.findByFlightName(flightName)).thenReturn(Collections.emptyList());

	        // Assert that a FlightNotFoundException is thrown
	        Exception exception = assertThrows(FlightNotFoundException.class,
	                () -> flightService.viewFlightsByFlightName(flightName));

	        // Assert the exception message
	        assertEquals("No flights found with the name: Nonexistent Flight", exception.getMessage());
	    }
	    
	    @Test
	    public void testGetSeatNumbers_Success() throws FlightNotFoundException {
	        int flightId = 1;
	        List<String> seatNumbers = Arrays.asList("1A", "1B", "1C");
	        Flight flight = new Flight();
	        flight.setSeatNumbers(seatNumbers);

	        when(repository.findById(flightId)).thenReturn(Optional.of(flight));

	        List<String> result = flightService.getSeatNumbers(flightId);

	        assertNotNull(result);
	        assertEquals(seatNumbers.size(), result.size());
	        assertEquals(seatNumbers, result);
	    }

	    /*
	    @Test
	    public void testGetSeatNumbers_Failure() {
	        int flightId = 1;

	        when(repository.findById(flightId)).thenReturn(Optional.empty());

	        FlightNotFoundException exception = assertThrows(FlightNotFoundException.class,
	                () -> flightService.getSeatNumbers(flightId));

	        assertEquals("No flights found with the Id: " + flightId, exception.getMessage());
	    }
		*/
	    @Test
	    public void testGetSeats_Success() throws FlightNotFoundException {
	        int flightId = 1;
	        int totalSeats = 150;
	        Flight flight = new Flight();
	        flight.setTotalSeats(totalSeats);

	        when(repository.findById(flightId)).thenReturn(Optional.of(flight));

	        int result = flightService.getSeats(flightId);

	        assertEquals(totalSeats, result);
	    }

	    /*
	    @Test
	    public void testGetSeats_Failure() {
	        int flightId = 1;

	        when(repository.findById(flightId)).thenReturn(Optional.empty());

	        FlightNotFoundException exception = assertThrows(FlightNotFoundException.class,
	                () -> flightService.getSeats(flightId));

	        assertEquals("No flights found with the Id: " + flightId, exception.getMessage());
	    }
	    */
	    
	    @Test
	    public void testSearchFlightBySourceAndDestinationAndDate_Success() throws FlightNotFoundException {
	        String source = "New York";
	        String destination = "London";
	        LocalDate date = LocalDate.of(2024, 7, 15);
	        List<Flight> flights = Arrays.asList(new Flight(), new Flight());

	        when(repository.findBySourceAndDestinationAndDate(source, destination, date)).thenReturn(flights);

	        List<Flight> result = flightService.searchFlightBySourceAndDestinationAndDate(source, destination, date);

	        assertNotNull(result);
	        assertEquals(flights.size(), result.size());
	        assertEquals(flights, result);
	    }

	    @Test
	    public void testSearchFlightBySourceAndDestinationAndDate_Failure() {
	        String source = "New York";
	        String destination = "London";
	        LocalDate date = LocalDate.of(2024, 7, 15);

	        when(repository.findBySourceAndDestinationAndDate(source, destination, date)).thenReturn(List.of());

	        FlightNotFoundException exception = assertThrows(FlightNotFoundException.class,
	                () -> flightService.searchFlightBySourceAndDestinationAndDate(source, destination, date));

	        assertEquals("No flights found for source: " + source + " and destination: " + destination + " on that day", exception.getMessage());
	    }

	    // Test cases for cancelSeats

	    @Test
	    public void testCancelSeats_Success() throws FlightNotFoundException {
	        int flightId = 1;
	        Flight flight = new Flight();
	        flight.setAvilableSeats(100);

	        when(repository.findById(flightId)).thenReturn(Optional.of(flight));
	        when(repository.save(any(Flight.class))).thenReturn(flight);

	        Flight result = flightService.cancelSeats(flightId);

	        assertNotNull(result);
	        assertEquals(101, result.getAvilableSeats());
	    }

	    /*
	    @Test
	    public void testCancelSeats_Failure() {
	        int flightId = 1;

	        when(repository.findById(flightId)).thenReturn(Optional.empty());

	        FlightNotFoundException exception = assertThrows(FlightNotFoundException.class,
	                () -> flightService.cancelSeats(flightId));

	        assertEquals("No flight found with the Id: " + flightId, exception.getMessage());
	    }
	    */
}
