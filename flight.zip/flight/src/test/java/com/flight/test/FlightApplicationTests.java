
 package com.flight.test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightApplicationTests {

		public void testname() throws Exception {
			
		}
}


